import mkdocs.plugins,mkdocs.config.config_options
import re

table='''
<div class="Crafting_Table">
        <span class="mcui mcui-Crafting_Table pixel-image">
            <span class="mcui-input">
                <span class="mcui-row">
                    <span class="invslot"></span><span class="invslot"></span><span class="invslot"></span>
                </span>
                <span class="mcui-row">
                    <span class="invslot"></span><span class="invslot"></span><span class="invslot"></span>
                </span>
                <span class="mcui-row">
                    <span class="invslot"></span><span class="invslot"></span><span class="invslot"></span>
                </span>
            </span>
            <span class="mcui-arrow">
                <br>
            </span>
            <span class="mcui-output">
                <span class="invslot invslot-large">
                    
                </span>
            </span>
        </span>
</div>
'''
class MyPlugin(mkdocs.plugins.BasePlugin):
    def on_page_markdown(self, markdown, /, *, page, config, files):
        num=re.sub(r'#table#',table,markdown)
        return num
    