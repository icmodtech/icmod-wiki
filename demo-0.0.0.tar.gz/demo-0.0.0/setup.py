from setuptools import setup, find_packages
setup(
    name="demo",
    author='yxy',
    author_email='188451334@qq.com',
    url='',
    packages=find_packages(),
    entry_points={
    'mkdocs.plugins': [
            'demo = demo.demo:MyPlugin'
        ]
    }
)